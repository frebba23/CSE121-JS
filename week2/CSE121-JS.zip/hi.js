// Add two numbers

let x = 5;
let y = 8;
let sum = x + y;
console.log(sum);

// Multiply two numbers

let product = x * y;
console.log(product);

// Subtract two numbers

let less = x - y;
console.log(less)

// concatinate two strings 

console.log('x' + 'y');

// Increment a value
let incre = ++x;
console.log(incre);

//comparison

console.log(x == y);

//less than 
console.log(x < y);

// Not equal
console.log(x !== y);

// less than 10 and greater than zero
console.log(x < 10 && x > 0);

